// The browser's side panel (chrome side_panel / firefox sidebar_action): the relationship map for
// the tab in front. On a search results page it maps the results and the searched name; on any
// other site it maps that site and grows one hop along its links. It follows tab switches and
// navigation, so it is a sidebar beside the page, never a window over it.
"use strict";
(() => {
const api = Shield.api;
const $ = (id) => document.getElementById(id);
const what = $("sp-what"), refresh = $("sp-refresh");
const state = { key: "", tabId: null, seeds: [], expand: [], name: "", hops: 2, busy: false, view: null };
const send = (m) => Shield.send(m);
// a test (or a link from the popup) can pin the panel to one tab with #tab=<id>
const pinned = Number((location.hash.match(/tab=(\d+)/) || [])[1]) || null;

state.view = Shield.relateView.create($("sp-map"), {
  onExpand: (site, button) => { if (!state.expand.includes(site)) state.expand.push(site); run(button); },
  onHistory: (site) => send({ type: "relate.history", host: site }),
  onOpen: (url) => api.tabs.create({ url }),
  hops: 2,
  onHops: (k, button) => { state.hops = k; run(button); },
});

async function frontTab() {
  if (pinned) return api.tabs.get(pinned).catch(() => null);
  const [tab] = await api.tabs.query({ active: true, lastFocusedWindow: true });
  return tab || null;
}
// the search page's own script knows its results; anything else is mapped as a site
async function seedsFor(tab) {
  const answer = await api.tabs.sendMessage(tab.id, { type: "relate.seeds" }).catch(() => null);
  if (answer && Array.isArray(answer.seeds) && answer.seeds.length) return { seeds: answer.seeds, name: answer.name || "", search: true };
  const u = new URL(tab.url);
  return { seeds: [{ url: u.origin + "/", title: tab.title || "", from: "pasted" }], name: "", search: false, site: u.hostname };
}
async function follow() {
  const tab = await frontTab();
  if (!tab || !/^https?:/.test(tab.url || "")) {
    state.key = "";
    what.textContent = "open a web page or a search: its map appears here";
    state.view.busy("nothing to map on this tab");
    return;
  }
  const key = tab.id + "|" + tab.url;
  if (key === state.key) return;
  state.key = key; state.tabId = tab.id; state.expand = [];
  const s = await seedsFor(tab);
  state.seeds = s.seeds; state.name = s.name;
  if (!s.search) state.expand = [Shield.siteOf(s.site)];
  what.textContent = s.search ? `results for “${s.name || "this search"}”` : `${Shield.siteOf(s.site)}: origin → the sites it links to → what those link to`;
  run();
}
async function run(button) {
  if (state.busy) return;
  state.busy = true;
  for (const b of [button, refresh]) if (b) b.setAttribute("aria-busy", "true");
  if (!state.view.graph) state.view.busy(`reading ${state.seeds.length} site${state.seeds.length === 1 ? "" : "s"}…`);
  const g = await send({ type: "relate.map", seeds: state.seeds, expand: state.expand, name: state.name, hops: state.hops }).catch((e) => ({ error: String(e) }));
  state.busy = false;
  for (const b of [button, refresh]) if (b) b.removeAttribute("aria-busy");
  if (!g || g.error) { state.view.error((g && g.error) || "the map could not be built"); return; }
  state.view.set(g);
}
refresh.addEventListener("click", () => { state.key = ""; follow(); });
api.tabs.onActivated.addListener(() => follow());
api.tabs.onUpdated.addListener((tabId, change) => { if (tabId === state.tabId && change.status === "complete") follow(); });
if (api.windows && api.windows.onFocusChanged) api.windows.onFocusChanged.addListener(() => follow());
(async () => { try { if (Shield.applyLook && Shield.loadLook) Shield.applyLook(await Shield.loadLook()); } catch {} follow(); })();
})();
