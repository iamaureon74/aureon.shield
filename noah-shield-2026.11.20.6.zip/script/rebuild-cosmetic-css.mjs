// Rebuilds rules/cosmetic.css as plain selector lists (bucketed by Blink by id/class/tag)
// instead of :is() groups, which every element had to test. Usage:
//   node script/rebuild-cosmetic-css.mjs rules/cosmetic.css rules/cosmetic.css   (needs playwright + chrome)
import { chromium } from 'playwright'; import fs from 'node:fs';
const src=fs.readFileSync(process.argv[2],'utf8');
const header=(src.match(/^\/\*[\s\S]*?\*\//)||[''])[0];
// parse ":is(a, b, ...) { display: none !important; }" blocks; selectors may contain commas inside parens
const sels=[];
const re=/:is\(([\s\S]*?)\)\s*\{\s*display:\s*none\s*!important;?\s*\}/g;
// manual paren-aware parse
let i=0;
while((i=src.indexOf(':is(',i))!==-1){ let d=0,j=i+3,start=i+4,parts=[],cur=start;
  for(;j<src.length;j++){const ch=src[j]; if(ch==='('||ch==='[')d++; else if(ch===')'||ch===']'){d--; if(d===0&&ch===')')break;} else if(ch===','&&d===1){parts.push(src.slice(cur,j).trim());cur=j+1;} else if((ch==='"'||ch==="'")){const q=ch;j++;while(j<src.length&&src[j]!==q){if(src[j]==='\\')j++;j++;}}}
  parts.push(src.slice(cur,j).trim()); sels.push(...parts.filter(Boolean)); i=j; }
const b=await chromium.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox']}); const p=await b.newPage();
const ok=await p.evaluate(list=>list.filter(s=>{try{document.createDocumentFragment().querySelector(s);return true}catch{return false}}),sels);
await b.close();
const out=[header.replace('*/',' plain selector lists (bucketed by id/class/tag); invalid selectors dropped at build. */')];
const safe=x=>!/:(?!not\(|nth-|first-|last-|only-|empty)[a-z-]+/i.test(x.replace(/\[[^\]]*\]/g,''));
const plain=ok.filter(safe), forgiving=ok.filter(x=>!safe(x));
for(let k=0;k<plain.length;k+=400) out.push(plain.slice(k,k+400).join(',\n')+' { display: none !important; }');
// newer pseudo-classes stay in forgiving :is() so one unsupported selector cannot void a whole block
for(let k=0;k<forgiving.length;k+=100) out.push(':is('+forgiving.slice(k,k+100).join(', ')+') { display: none !important; }');
console.log('plain',plain.length,'forgiving',forgiving.length);
fs.writeFileSync(process.argv[3],out.join('\n')+'\n');
console.log('parsed',sels.length,'valid',ok.length,'dropped',sels.length-ok.length, sels.filter(s=>!ok.includes(s)).slice(0,5));
