// Site archetype reader. Injected on demand by the popup (scripting.executeScript),
// never on every page: it reads the page once, changes nothing, sends nothing
// over the network, and returns a plain object as the script's last value.
//
// What it computes (taxonomy "site-archetypes v1"):
//   - the page's "face": the context it presents (storefront, article, feed…)
//   - similarity (0–100) to twelve symbolic archetypes; the scores overlap and
//     do not add to 100 — similarity is not the probability a site "is" one
//   - why: the strongest observed cues behind the top archetype, and what
//     weakens it
//   - the emotional pull of the page (happy, respect, awe, love, fear, hate)
//     as shares that add to 100, estimated from words, colour, type, layout and
//     pressure tactics — a model of the page, not a measurement of anyone.
(() => {
  "use strict";
  const T0 = performance.now();
  const VERSION = "site-archetypes v1";

  // ---- archetypes: definition, words, and the visual cues they usually carry
  const ARCHETYPES = {
    ruler: { name: "the ruler", line: "authority, order, prestige — it wants you to trust its standard.",
      words: ["premium", "exclusive", "luxury", "elite", "leader", "leading", "official", "enterprise", "executive", "prestige", "world-class", "authority", "standard", "invest", "wealth", "private", "heritage", "since 18", "since 19", "excellence", "finest", "trusted by", "fortune 500", "institutional"],
      cues: ["dark", "serif", "restrained", "space", "goldish"] },
    sage: { name: "the sage", line: "knowledge and explanation — it wants you to understand.",
      words: ["learn", "research", "study", "knowledge", "guide", "explained", "evidence", "data", "insight", "analysis", "science", "understand", "documentation", "docs", "reference", "how to", "why", "theory", "university", "journal", "faq", "tutorial", "course", "lesson", "definition", "according to", "published", "references", "abstract", "method"],
      cues: ["dense", "longread", "fewimages", "citations", "code"] },
    trickster: { name: "the trickster", line: "play, surprise, irreverence — it wants you to laugh and stay.",
      words: ["fun", "lol", "meme", "play", "joke", "laugh", "silly", "weird", "wild", "crazy", "prank", "surprise", "party", "lmao", "epic fail", "random", "chaos", "vibes", "goofy", "hilarious"],
      cues: ["saturated", "multihue", "emoji", "exclaim", "rounded"] },
    protector: { name: "the protector", line: "care and safety — it wants you to feel looked after.",
      words: ["protect", "safe", "safety", "secure", "security", "care", "support", "help", "health", "family", "trust", "privacy", "insurance", "guard", "shield", "wellbeing", "patient", "donate", "charity", "emergency", "assist", "relief", "nurse", "covered"],
      cues: ["blue", "trustlinks", "calm", "forms"] },
    rebel: { name: "the rebel", line: "defiance and freedom — it wants you to break with the crowd.",
      words: ["break the rules", "disrupt", "revolution", "rebel", "fight", "against", "freedom", "uncensored", "rogue", "defy", "radical", "no limits", "unfiltered", "raw", "underground", "resist", "anti", "the system", "wake up", "mainstream", "banned", "censored"],
      cues: ["dark", "redblack", "caps", "contrast"] },
    creator: { name: "the creator", line: "making and imagination — it wants you to build something.",
      words: ["create", "build", "make", "design", "craft", "studio", "portfolio", "imagine", "compose", "template", "canvas", "editor", "publish", "open source", "maker", "draw", "draft", "project", "workspace", "prototype", "remix"],
      cues: ["images", "tools", "multihue"] },
    explorer: { name: "the explorer", line: "discovery and freedom of movement — it wants you to go further.",
      words: ["explore", "discover", "adventure", "travel", "journey", "world", "outdoor", "trail", "destination", "map", "expedition", "roam", "escape", "wander", "horizon", "wilderness", "trip", "tour", "beyond", "camp"],
      cues: ["bigimage", "earth", "video"] },
    siren: { name: "the siren", line: "attraction and desire — it wants your attention to linger.",
      words: ["beautiful", "desire", "seduc", "irresistible", "sensual", "glow", "romance", "passion", "fragrance", "fashion", "gorgeous", "intimate", "dating", "crush", "allure", "beauty", "sexy", "luxurious", "indulge", "flawless", "skin", "lips"],
      cues: ["warm", "bigimage", "serif", "pinkpurple"] },
    hero: { name: "the hero", line: "mastery and courage — it wants you to rise to a challenge.",
      words: ["win", "champion", "achieve", "challenge", "performance", "strength", "courage", "victory", "compete", "mission", "impact", "bold", "unstoppable", "goal", "train", "power", "push", "limits", "beat", "record", "elite performance", "fearless"],
      cues: ["heavy", "caps", "warm", "contrast"] },
    magician: { name: "the magician", line: "transformation — it promises the impossible made easy.",
      words: ["transform", "magic", "instantly", "effortless", "ai", "intelligent", "smart", "powered", "automate", "reimagine", "vision", "wonder", "future", "innovate", "breakthrough", "unlock", "seamless", "in seconds", "next-gen", "revolutionary", "genius"],
      cues: ["dark", "pinkpurple", "gradient", "glow"] },
    innocent: { name: "the innocent", line: "simplicity and goodness — it wants you to feel safe and light.",
      words: ["simple", "pure", "natural", "organic", "clean", "fresh", "honest", "gentle", "kind", "wholesome", "calm", "easy", "light", "happy", "plant", "nourish", "mindful", "soft", "sunshine"],
      cues: ["light", "pastel", "rounded", "space"] },
    everyman: { name: "the everyman", line: "belonging and the ordinary — it wants you to feel at home.",
      words: ["everyone", "everyday", "people", "community", "neighbor", "neighbour", "affordable", "deals", "real", "together", "local", "friendly", "belong", "join", "members", "regular", "low price", "value", "save", "reviews", "forum", "for all"],
      cues: ["plainfont", "ugc", "prices"] },
  };

  // ---- emotional lexicons -----------------------------------------------
  const EMO_WORDS = {
    happy: ["fun", "joy", "enjoy", "smile", "happy", "celebrate", "delight", "yay", "awesome", "love it", "great", "amazing", "free", "bonus", "treat", "sunny", "cheer", "congrat", "welcome", "woohoo"],
    respect: ["research", "evidence", "certified", "accredited", "official", "established", "peer-reviewed", "according to", "published", "transparent", "methodology", "verified", "audit", "standards", "compliance", "award", "since 18", "since 19", "references", "sources"],
    awe: ["discover", "universe", "extraordinary", "breathtaking", "infinite", "epic", "stunning", "cosmos", "majestic", "legendary", "monumental", "vast", "wonder", "spectacular", "timeless", "beyond", "incredible", "masterpiece", "sublime", "galaxy"],
    love: ["love", "heart", "together", "family", "cherish", "friends", "community", "kindness", "romance", "care", "beloved", "hug", "gift", "forever", "warmth", "share", "dear", "sweet", "adore", "bond"],
    fear: ["risk", "danger", "warning", "threat", "attack", "breach", "lose", "losing", "miss out", "last chance", "too late", "scam", "crisis", "urgent", "hurry", "expires", "left in stock", "act now", "don't miss", "before it's gone", "alert", "virus", "hacked", "deadline", "limited time"],
    hate: ["hate", "stupid", "idiot", "disgusting", "destroy", "enemy", "outrage", "liar", "traitor", "scum", "pathetic", "evil", "corrupt", "shameful", "worst", "garbage", "trash", "clown", "moron", "vile", "furious", "rage"],
  };

  // ---- small helpers -----------------------------------------------------
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const visible = (el) => {
    if (!el || !el.getClientRects || !el.getClientRects().length) return false;
    const s = getComputedStyle(el);
    return s.visibility !== "hidden" && s.display !== "none" && Number(s.opacity) > 0.05;
  };
  const parseColor = (str) => {
    const m = /rgba?\(([\d.]+)[ ,]+([\d.]+)[ ,]+([\d.]+)(?:[ ,/]+([\d.]+%?))?\)/.exec(str || "");
    if (!m) return null;
    let a = m[4] === undefined ? 1 : m[4].endsWith("%") ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
    return { r: +m[1], g: +m[2], b: +m[3], a };
  };
  const hsl = ({ r, g, b }) => {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2;
    if (max === min) return { h: 0, s: 0, l };
    const d = max - min;
    const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    let h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
    return { h: h * 60, s, l };
  };
  const lum = ({ r, g, b }) => {
    const f = (c) => { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
  };
  const contrast = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  const hueName = (c) => {
    const { h, s, l } = hsl(c);
    if (s < 0.15 || l < 0.08 || l > 0.95) return l < 0.25 ? "black" : l > 0.8 ? "white" : "grey";
    if (h < 15 || h >= 345) return "red";
    if (h >= 30 && h < 65 && s < 0.6 && l < 0.65) return "gold";
    if (h < 45) return "orange";
    if (h < 65) return "yellow";
    if (h < 170) return "green";
    if (h < 200) return "teal";
    if (h < 255) return "blue";
    if (h < 290) return "purple";
    return "pink";
  };
  // The canvas takes the root's background, or the body's when the root has
  // none (CSS background propagation), so empty space below short content
  // still reads as the page's colour.
  const canvasBg = (() => {
    for (const node of [document.documentElement, document.body]) {
      const c = node && parseColor(getComputedStyle(node).backgroundColor);
      if (c && c.a > 0.5) return c;
    }
    return { r: 255, g: 255, b: 255, a: 1 };
  })();
  const bgOf = (el) => {
    for (let node = el; node && node.nodeType === 1 && node !== document.documentElement && node !== document.body; node = node.parentElement) {
      const c = parseColor(getComputedStyle(node).backgroundColor);
      if (c && c.a > 0.5) return c;
    }
    return canvasBg;
  };

  // ---- text: weighted by where it sits ----------------------------------
  const MAX_TEXT = 60000;
  const parts = [];
  let words = 0;
  const pushText = (str, weight) => {
    const t = (str || "").replace(/\s+/g, " ").trim();
    if (!t) return;
    parts.push({ t: t.toLowerCase(), raw: t, w: weight });
    words += t.split(" ").length;
  };
  pushText(document.title, 4);
  const metaDesc = document.querySelector('meta[name="description" i], meta[property="og:description" i]');
  if (metaDesc) pushText(metaDesc.getAttribute("content"), 3);
  const heads = Array.from(document.querySelectorAll("h1, h2, h3")).filter(visible).slice(0, 60);
  heads.forEach((h) => pushText(h.textContent, h.tagName === "H1" ? 4 : 2.5));
  const ctas = Array.from(document.querySelectorAll("button, a[role=button], [class*='btn' i], input[type=submit]")).filter(visible).slice(0, 80);
  ctas.forEach((b) => pushText(b.textContent || b.value, 2));
  const bodyText = (document.body ? document.body.innerText || "" : "").slice(0, MAX_TEXT);
  pushText(bodyText, 1);
  const bodyWords = Math.max(1, bodyText.split(/\s+/).filter(Boolean).length);

  // Counts matches of a word list across the weighted text; returns score and the words seen.
  const escape = (w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const regexCache = new Map();
  const termRegex = (w) => {
    if (!regexCache.has(w)) {
      // short words need a full-word match; stems like "seduc" match as prefixes
      const src = w.length <= 3 ? "\\b" + escape(w) + "\\b" : "\\b" + escape(w);
      regexCache.set(w, new RegExp(src, "g"));
    }
    return regexCache.get(w);
  };
  function lexicon(list) {
    let total = 0;
    const seen = [];
    for (const w of list) {
      const re = termRegex(w);
      let n = 0;
      for (const p of parts) { re.lastIndex = 0; const m = p.t.match(re); if (m) n += m.length * p.w; }
      if (n) { total += n; seen.push([w, n]); }
    }
    seen.sort((a, b) => b[1] - a[1]);
    // density, damped: long pages don't win by length alone
    const density = (total / Math.sqrt(words + 50)) * 4;
    const shown = (w) => /^since 1[89]$/.test(w) ? w + "xx" : w === "seduc" ? "seduce" : w;
    return { score: clamp(density, 0, 40), top: seen.slice(0, 4).map(([w]) => shown(w)), raw: total };
  }

  // ---- first screen: colour, imagery, type -------------------------------
  const vw = innerWidth, vh = innerHeight;
  // Pop-ups that cover the screen are counted (they pull toward fear) but the
  // colours are read from the page beneath them.
  const overlayEls = Array.from(document.querySelectorAll("body *")).slice(0, 4000).filter((el) => {
    const s = getComputedStyle(el);
    if (s.position !== "fixed" || s.display === "none" || s.visibility === "hidden") return false;
    const r = el.getBoundingClientRect();
    return r.width * r.height > vw * vh * 0.35;
  });
  const overlays = overlayEls.length;
  const inOverlay = (el) => overlayEls.some((o) => o.contains(el));

  const hueCount = {};
  let sat = 0, light = 0, samples = 0, imageHits = 0, videoHits = 0;
  const bgSeen = [];
  for (let gx = 1; gx <= 8; gx++) {
    for (let gy = 1; gy <= 6; gy++) {
      const x = (gx / 9) * vw, y = (gy / 7) * vh;
      const el = overlayEls.length ? document.elementsFromPoint(x, y).find((e) => !inOverlay(e)) : document.elementFromPoint(x, y);
      if (!el) continue;
      samples++;
      const tag = el.tagName;
      const style = getComputedStyle(el);
      if (tag === "IMG" || tag === "PICTURE" || tag === "CANVAS" || tag === "SVG" || (style.backgroundImage && style.backgroundImage.includes("url("))) imageHits++;
      if (tag === "VIDEO" || el.closest("video")) videoHits++;
      const c = bgOf(el);
      bgSeen.push(c);
      const p = hsl(c);
      sat += p.s; light += p.l;
      const name = hueName(c);
      hueCount[name] = (hueCount[name] || 0) + 1;
    }
  }
  samples = Math.max(1, samples);
  const avgSat = sat / samples, avgLight = light / samples;
  const imageShare = imageHits / samples;
  // Accent: the colour of the most prominent buttons and links.
  const accentHues = {};
  let accentSat = 0, accentN = 0, radiusSum = 0, radiusN = 0;
  for (const b of ctas.slice(0, 30)) {
    const s = getComputedStyle(b);
    const c = parseColor(s.backgroundColor);
    const use = c && c.a > 0.5 ? c : parseColor(s.color);
    if (use) { const n = hueName(use); accentHues[n] = (accentHues[n] || 0) + 1; accentSat += hsl(use).s; accentN++; }
    const r = parseFloat(s.borderTopLeftRadius) || 0;
    const h = b.getBoundingClientRect().height || 1;
    radiusSum += clamp(r / h, 0, 0.5); radiusN++;
  }
  // Headline colour counts as an accent too (a red headline on black is a choice).
  for (const h of heads.slice(0, 4)) {
    const c = parseColor(getComputedStyle(h).color);
    if (c && hsl(c).s > 0.4) { const n = hueName(c); accentHues[n] = (accentHues[n] || 0) + 2; }
  }
  const accent = Object.entries(accentHues).sort((a, b) => b[1] - a[1]).map(([k]) => k)[0] || "";
  const roundness = radiusN ? radiusSum / radiusN : 0;
  const hues = Object.entries(hueCount).filter(([k]) => !["black", "white", "grey"].includes(k));
  const colourHues = hues.length + (accent && !["black", "white", "grey"].includes(accent) && !hueCount[accent] ? 1 : 0);
  const dark = avgLight < 0.35;
  const has = (...names) => names.some((n) => (hueCount[n] || 0) + (accentHues[n] || 0) * 2 >= 3 || accent === n);

  const h1 = heads.find((h) => h.tagName === "H1") || heads[0];
  const para = document.querySelector("article p, main p, p");
  const fontOf = (el) => (el ? getComputedStyle(el).fontFamily.toLowerCase() : "");
  // A page with no styles of its own shows the browser's default serif: not a choice.
  // (an inline display:none does not make a page "styled"; only real font choices count)
  const styled = document.styleSheets.length > 0 || document.querySelector('[style*="font" i]') !== null;
  const isSerif = (f) => styled && ( /serif/.test(f) && !/sans-serif/.test(f) || /georgia|times|garamond|playfair|baskerville|didot|bodoni|merriweather|lora|caslon/.test(f));
  const headFont = fontOf(h1), bodyFont = fontOf(para || document.body);
  const h1Style = h1 ? getComputedStyle(h1) : null;
  const h1Size = h1Style ? parseFloat(h1Style.fontSize) : 0;
  const bodySize = parseFloat(getComputedStyle(para || document.body).fontSize) || 16;
  const scale = h1Size / bodySize;
  const heavy = h1Style ? Number(h1Style.fontWeight) >= 750 : false;
  const capsHead = heads.slice(0, 10).filter((h) => getComputedStyle(h).textTransform === "uppercase" || (h.textContent.trim().length > 6 && h.textContent === h.textContent.toUpperCase() && /[A-Z]/.test(h.textContent))).length;
  const plainFont = /system-ui|-apple-system|segoe ui|roboto|arial|helvetica/.test(bodyFont);
  const textColor = parseColor(getComputedStyle(para || document.body).color) || { r: 0, g: 0, b: 0 };
  const pageContrast = contrast(textColor, bgOf(para || document.body));
  const gradient = Array.from(document.querySelectorAll("header, section, main, [class*='hero' i]")).slice(0, 30).some((el) => /gradient\(/.test(getComputedStyle(el).backgroundImage));
  const glow = ctas.slice(0, 20).some((b) => { const s = getComputedStyle(b); return s.boxShadow !== "none" && /rgba?\((?!0, 0, 0)/.test(s.boxShadow); });

  // ---- structure ---------------------------------------------------------
  const q = (sel) => document.querySelectorAll(sel).length;
  const ld = Array.from(document.querySelectorAll('script[type="application/ld+json"]')).map((s) => s.textContent || "").join(" ");
  const images = Array.from(document.images).filter((i) => i.naturalWidth * i.naturalHeight > 40000 || i.width * i.height > 40000).length;
  const prices = (bodyText.match(/(?:[$€£¥₹]\s?\d[\d,.]*|\d[\d,.]*\s?(?:USD|EUR|GBP|kr|zł))/g) || []).length;
  const emojis = (bodyText.match(/\p{Extended_Pictographic}/gu) || []).length;
  const exclaims = (bodyText.match(/!/g) || []).length;
  const letters = bodyText.replace(/[^A-Za-z]/g, "");
  const capsRatio = letters.length > 200 ? (bodyText.match(/\b[A-Z]{4,}\b/g) || []).join("").length / letters.length : 0;
  const links = Array.from(document.querySelectorAll("a[href]")).slice(0, 1500);
  const linkText = links.map((a) => (a.textContent || "") + " " + a.getAttribute("href")).join(" ").toLowerCase();
  const trustLinks = ["privacy", "terms", "about", "contact", "imprint", "impressum", "accessibility", "security"].filter((w) => linkText.includes(w));
  const citations = q("cite, sup a[href^='#'], .references li, ol.references li, [class*='footnote' i], [class*='citation' i]");
  const code = q("pre code, pre");
  const forms = q("form");
  const pass = q("input[type=password]");
  const tools = q("canvas, [contenteditable=true], textarea, input[type=range], input[type=color]");
  const ugc = q("[class*='comment' i], [class*='review' i], [itemprop=review], [id*='comment' i]");
  const articleish = q("article") > 0 || /"@type"\s*:\s*"(News)?Article"/i.test(ld);
  const product = /"@type"\s*:\s*"(Product|Offer)"/i.test(ld) || q("[itemtype*='Product' i]") > 0;
  const repeated = (() => {
    // a feed: many siblings with the same tag+class under one parent
    let best = 0;
    for (const parent of Array.from(document.querySelectorAll("main, [role=feed], ul, ol, div")).slice(0, 1200)) {
      const kids = parent.children;
      if (kids.length < 8) continue;
      const sig = (k) => k.tagName + "." + (typeof k.className === "string" ? k.className.split(" ")[0] : "");
      const first = sig(kids[0]);
      let same = 0;
      for (const k of kids) if (sig(k) === first) same++;
      best = Math.max(best, same);
    }
    return best;
  })();
  const hasMap = q("iframe[src*='map' i], [class*='mapbox' i], [class*='leaflet' i]") > 0;
  const hasVideo = q("video, iframe[src*='youtube' i], iframe[src*='vimeo' i]") > 0 || videoHits > 0;

  // ---- pressure: the things that pull toward fear -------------------------
  const urgency = (bodyText.match(/\b(hurry|last chance|ends (soon|today|in)|only \d+ left|limited time|act now|don'?t miss|before it'?s gone|selling fast|almost gone|expires? (soon|in|today))\b/gi) || []).length;
  const timers = (bodyText.match(/\b\d{1,2}:\d{2}(:\d{2})?\b/g) || []).length > 0 && /ends|left|remaining|expires|offer|sale/i.test(bodyText) ? 1 : 0;
  const confirmShame = (bodyText.match(/no thanks,? i (don'?t|do not|hate|prefer)|i'?d rather (pay|miss)|i don'?t (want|like) (to save|deals|discounts)/gi) || []).length;

  // ---- face (the presentation this page gives in this context) -----------
  const path = location.pathname.toLowerCase();
  let face = "landing page";
  if (/\/(cart|checkout|basket|bag|payment)/.test(path)) face = "checkout";
  else if (pass) face = "sign-in gate";
  else if (/\/(settings|account|preferences|profile)/.test(path)) face = "account";
  else if (code > 2 || /\/(docs?|reference|api|manual)\b/.test(path)) face = "reference";
  else if (product || (prices > 3 && ctas.some((b) => /add to (cart|bag|basket)|buy/i.test(b.textContent)))) face = "storefront";
  else if (repeated >= 12 && bodyWords > 300) face = "feed";
  else if (tools >= 2) face = "tool / app";
  else if (articleish || bodyWords > 1200) face = "article";
  else if (hasVideo && imageShare > 0.3) face = "media";

  // ---- archetype similarity ------------------------------------------------
  const cueTests = {
    dark: [dark, "dark theme"],
    light: [avgLight > 0.75, "light, airy background"],
    serif: [isSerif(headFont), "serif display type"],
    restrained: [colourHues <= 2 && avgSat < 0.3, "restrained palette (" + Math.max(1, colourHues) + " hue" + (Math.max(1, colourHues) === 1 ? "" : "s") + ")"],
    space: [bodyWords / Math.max(1, (document.documentElement.scrollHeight / vh)) < 180, "generous white space"],
    goldish: [has("gold", "yellow") && dark, "gold on dark"],
    dense: [bodyWords > 900, "dense text (" + bodyWords + " words)"],
    longread: [articleish || bodyWords > 1500, "long-form reading"],
    fewimages: [images <= 3, "few images"],
    citations: [citations > 2, "citations / footnotes (" + citations + ")"],
    code: [code > 0, "code samples"],
    saturated: [avgSat > 0.45 || accentSat / Math.max(1, accentN) > 0.7, "saturated colour"],
    multihue: [colourHues >= 3, "many hues (" + colourHues + ")"],
    emoji: [emojis >= 3, "emoji (" + emojis + ")"],
    exclaim: [exclaims / bodyWords > 0.01, "lots of exclamation marks"],
    rounded: [roundness > 0.3, "pill-shaped, rounded buttons"],
    blue: [has("blue", "teal"), "blue / teal palette"],
    trustlinks: [trustLinks.length >= 3, "trust links (" + trustLinks.slice(0, 4).join(", ") + ")"],
    calm: [urgency === 0 && overlays === 0 && avgSat < 0.45, "no pressure tactics"],
    forms: [forms > 0, "forms that ask for details"],
    redblack: [has("red") && (dark || has("black")), "red against black"],
    caps: [capsHead >= 2, "uppercase headlines"],
    contrast: [pageContrast > 12, "hard contrast"],
    images: [images >= 8, "image-led (" + images + " large images)"],
    tools: [tools >= 2, "making tools on the page (canvas / editors)"],
    bigimage: [imageShare > 0.35, "first screen is mostly imagery"],
    earth: [has("green", "teal", "orange"), "earth / sky colours"],
    video: [hasVideo, "video"],
    warm: [has("red", "orange", "pink"), "warm palette"],
    pinkpurple: [has("pink", "purple"), "pink / purple tones"],
    heavy: [heavy, "heavy display weight"],
    gradient: [gradient, "colour gradients"],
    glow: [glow, "glowing buttons"],
    pastel: [avgLight > 0.75 && avgSat > 0.15 && avgSat < 0.6, "pastel tones"],
    plainfont: [plainFont, "plain system type"],
    ugc: [ugc > 3, "people's comments / reviews (" + ugc + ")"],
    prices: [prices > 5, "prices everywhere (" + prices + ")"],
  };
  const results = [];
  for (const [key, a] of Object.entries(ARCHETYPES)) {
    const lex = lexicon(a.words);
    const met = a.cues.filter((c) => cueTests[c] && cueTests[c][0]);
    const missed = a.cues.filter((c) => cueTests[c] && !cueTests[c][0]);
    let score = lex.score * 1.6 + (met.length / a.cues.length) * 38;
    if (key === "sage" && face === "reference") score += 10;
    if (key === "everyman" && face === "feed") score += 6;
    if (key === "creator" && face === "tool / app") score += 10;
    if (key === "explorer" && hasMap) score += 8;
    results.push({ key, name: a.name, line: a.line, score: Math.round(clamp(score, 0, 100)), lex, met, missed });
  }
  results.sort((a, b) => b.score - a.score);

  // ---- emotional pull ----------------------------------------------------
  const emo = {};
  const emoWhy = {};
  for (const [k, list] of Object.entries(EMO_WORDS)) { const l = lexicon(list); emo[k] = l.score; emoWhy[k] = l.top.length ? ["words: " + l.top.slice(0, 3).join(", ")] : []; }
  const add = (k, v, why) => { if (v > 0) { emo[k] += v; if (why) emoWhy[k].push(why); } };
  add("happy", avgLight > 0.6 && avgSat > 0.35 ? 8 : 0, "bright, saturated colour");
  add("happy", emojis >= 3 ? Math.min(8, emojis) : 0, "emoji");
  add("happy", roundness > 0.3 ? 3 : 0, "soft, rounded shapes");
  add("respect", trustLinks.length * 1.5, trustLinks.length ? "trust links: " + trustLinks.slice(0, 3).join(", ") : "");
  add("respect", citations > 2 ? 6 : 0, "citations");
  add("respect", colourHues <= 2 && urgency === 0 ? 5 : 0, "restraint: few colours, no pressure");
  add("respect", isSerif(headFont) || isSerif(bodyFont) ? 3 : 0, "serif type");
  add("respect", location.protocol === "https:" ? 2 : 0, "");
  add("awe", imageShare > 0.35 ? 10 * imageShare : 0, "first screen filled with imagery");
  add("awe", scale >= 3 ? Math.min(8, scale * 1.5) : 0, "very large display type (" + scale.toFixed(1) + "× body)");
  add("awe", dark && (avgSat > 0.3 || accentSat / Math.max(1, accentN) > 0.6) ? 5 : 0, "vivid accent on dark");
  add("awe", hasVideo ? 4 : 0, "video");
  add("love", has("red", "pink") && !urgency && !overlays && emo.hate === 0 ? 5 : 0, "warm reds / pinks");
  add("love", ugc > 3 ? 3 : 0, "people talking to each other");
  add("fear", urgency * 4 + timers * 6, urgency || timers ? "urgency / countdowns (" + (urgency + timers) + ")" : "");
  add("fear", overlays * 5, overlays ? "screen-blocking overlays (" + overlays + ")" : "");
  add("fear", confirmShame * 5, confirmShame ? "guilt-trip opt-outs" : "");
  add("fear", has("red") && (urgency || overlays) ? 4 : 0, "alarm red");
  // Capitals and exclamation marks are excitement on a toy shop and anger on
  // an outrage page: they only add to hate where hostile words are present.
  const hostile = emo.hate > 0;
  add("hate", hostile && capsRatio > 0.04 ? capsRatio * 120 : 0, "shouting in capitals");
  add("hate", hostile && exclaims / bodyWords > 0.02 ? 5 : 0, "exclamation-heavy");
  add("hate", confirmShame * 3, confirmShame ? "opt-outs that mock you" : "");
  const BASE = 2; // every page carries a little of each; nothing is ever 0 by default
  const keys = ["happy", "respect", "awe", "love", "fear", "hate"];
  const rawSum = keys.reduce((s, k) => s + emo[k] + BASE, 0);
  // largest-remainder rounding so the six shares add to exactly 100
  const exact = keys.map((k) => ((emo[k] + BASE) / rawSum) * 100);
  const floored = exact.map(Math.floor);
  let left = 100 - floored.reduce((a, b) => a + b, 0);
  exact.map((v, i) => [v - floored[i], i]).sort((a, b) => b[0] - a[0]).forEach(([, i]) => { if (left-- > 0) floored[i]++; });
  const emotions = keys.map((k, i) => ({ key: k, pct: floored[i], why: emoWhy[k].filter(Boolean).slice(0, 2) }));

  // ---- confidence and the explanation ------------------------------------
  const evidence = bodyWords + (results[0].met.length * 120) + samples * 5;
  const confidence = bodyWords < 40 || results[0].score < 30 ? "low" : evidence > 1200 && results[0].score - results[1].score >= 8 ? "high" : "medium";
  const top = results[0];
  const insufficient = (bodyWords < 25 && top.met.length < 2) || top.score < 20;
  const why = [];
  if (top.lex.top.length) why.push("its words lean " + top.key + ": “" + top.lex.top.slice(0, 3).join("”, “") + "”");
  top.met.forEach((c) => why.push(cueTests[c][1]));
  if (face) why.push("it shows a " + face + " face here");
  const against = top.missed.map((c) => "no " + cueTests[c][1].replace(/ \(.*\)$/, ""));
  if (results[1].score >= top.score - 6) against.unshift("almost as close to " + results[1].name + " (" + results[1].score + ")");

  return {
    version: VERSION,
    url: location.href,
    host: location.hostname,
    face,
    words: bodyWords,
    confidence,
    insufficient,
    archetypes: results.map(({ key, name, line, score }) => ({ key, name, line, score })),
    primary: insufficient ? null : { key: top.key, name: top.name, line: top.line, score: top.score },
    why: insufficient ? [] : why.slice(0, 6),
    against: insufficient ? [] : against.slice(0, 4),
    emotions,
    signals: { dark, avgLight: +avgLight.toFixed(2), avgSat: +avgSat.toFixed(2), hues: colourHues, accent, imageShare: +imageShare.toFixed(2), scale: +scale.toFixed(1), urgency, overlays, trustLinks: trustLinks.length, images, prices },
    ms: Math.round(performance.now() - T0),
  };
})();
