// Design & interface reader ("interface intelligence"). Injected on demand by the
// popup / security center (scripting.executeScript), never on every page. Read-only:
// no DOM writes, no storage, no network. Returns a plain object as its last value.
//
// It measures what the shepherd aesthetics + psychology dataset asks of an interface,
// using only what the rendered page exposes:
//   readability   text contrast against its real background (WCAG 2.x AA)
//   targets       size of tap/click targets (WCAG 2.5.8 minimum 24px; 44px comfortable)
//   type          size steps, body size, line height, line length
//   hierarchy     one h1, heading order, the h1 as the first screen's largest text, one primary action
//   rhythm        spacing on a 4px grid, how many distinct spacings
//   shape         corner-radius family, shadow family
//   colour        palette size and number of competing accents
//   access        alt text, labelled fields, page language, landmarks, visible focus
//   motion        running / endless animation, reduced-motion support, autoplay
//   load          choices on the first screen (hick-hyman), blocking overlays
// Each dimension scores 0–100 with the evidence behind it and one concrete fix.
(() => {
  "use strict";
  const T0 = performance.now();
  const VERSION = "interface-intelligence v1";
  const vw = innerWidth, vh = innerHeight;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const round = (v) => Math.round(v);
  const parse = (c) => { const m = /rgba?\(([\d.]+)[ ,]+([\d.]+)[ ,]+([\d.]+)(?:[ ,/]+([\d.]+%?))?\)/.exec(c || ""); if (!m) return null; const a = m[4] === undefined ? 1 : m[4].endsWith("%") ? parseFloat(m[4]) / 100 : +m[4]; return [+m[1], +m[2], +m[3], a]; };
  const lum = (c) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
  const ratio = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  const over = (top, under) => [0, 1, 2].map((i) => top[i] * top[3] + under[i] * (1 - top[3])).concat(1);
  const visible = (el) => { const r = el.getBoundingClientRect(); if (!r.width || !r.height) return false; const s = getComputedStyle(el); return s.visibility !== "hidden" && s.display !== "none" && +s.opacity > 0.05; };
  const canvas = (() => { for (const n of [document.documentElement, document.body]) { const c = n && parse(getComputedStyle(n).backgroundColor); if (c && c[3] > 0.5) return c; } return [255, 255, 255, 1]; })();
  // background behind an element: blend translucent layers; stop (unknown) at an image
  const bgOf = (el) => {
    const layers = [];
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      const s = getComputedStyle(n);
      if (s.backgroundImage && s.backgroundImage !== "none" && /url\(|gradient/.test(s.backgroundImage)) return null;
      const c = parse(s.backgroundColor);
      if (c && c[3] > 0) { layers.push(c); if (c[3] >= 1) break; }
    }
    let bg = canvas;
    for (const c of layers.reverse()) bg = over(c, bg);
    return bg;
  };
  const dims = [];
  // needs: whether the fix is a real change (false = "keep doing this")
  const add = (key, label, score, evidence, fix, weight = 1, needs = score < 85) => dims.push({ key, label, score: round(clamp(score, 0, 100)), evidence: evidence.filter(Boolean).slice(0, 4), fix, weight, needs });

  // ---- collect text samples -----------------------------------------------------------------
  const texts = [];
  const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
  const seen = new Set();
  for (let n = walker.nextNode(); n && texts.length < 500; n = walker.nextNode()) {
    const el = n.parentElement;
    const t = n.nodeValue.trim();
    if (!el || !t || seen.has(el) || /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|OPTION)$/.test(el.tagName)) continue;
    seen.add(el);
    if (!visible(el)) continue;
    texts.push({ el, len: t.length, style: getComputedStyle(el) });
  }
  const words = texts.reduce((s, t) => s + t.len, 0);

  // ---- 1. readability (contrast) -----------------------------------------------------------------
  let pass = 0, measured = 0, onImage = 0;
  const worst = [];
  for (const t of texts.slice(0, 400)) {
    const fg = parse(t.style.color); if (!fg) continue;
    // inactive controls are exempt from the contrast rule (WCAG 1.4.3)
    if (t.el.closest(":disabled, [disabled], [aria-disabled='true'], .disabled, .is-disabled")) continue;
    const bg = bgOf(t.el);
    if (!bg) { onImage++; continue; }
    const size = parseFloat(t.style.fontSize), bold = +t.style.fontWeight >= 700;
    const need = size >= 24 || (bold && size >= 18.66) ? 3 : 4.5;
    const cr = ratio(over(fg, bg), bg);
    // ~1:1 on visible text means its real background is a layer the page does not expose
    // (a pseudo-element, an image, a canvas): count it as unmeasurable, not as a failure
    if (cr < 1.25) { onImage++; continue; }
    measured++;
    if (cr >= need) pass++; else worst.push([cr, t.el.textContent.trim().slice(0, 28), need, t.el.tagName.toLowerCase() + (t.el.classList[0] ? "." + t.el.classList[0] : ""), fg, bg]);
  }
  worst.sort((a, b) => a[0] - b[0]);
  const contrastShare = measured ? pass / measured : 1;
  add("readability", "readability", contrastShare * 100,
    [`${pass} of ${measured} text samples meet WCAG AA`, worst[0] ? `weakest: “${worst[0][1]}” (${worst[0][3]}) at ${worst[0][0].toFixed(1)}:1 (needs ${worst[0][2]}:1)` : "", onImage ? `${onImage} sit on images, gradients or hidden layers (not measurable from the page)` : ""],
    worst.length ? "raise the contrast of muted text and links to at least 4.5:1 (3:1 for large type)" : "keep this contrast as the palette evolves", 1.4, worst.length > 0);

  // ---- 2. targets ---------------------------------------------------------------------------------
  // visually-hidden controls (1–2px, the screen-reader technique) are not tap targets
  const controls = [...document.querySelectorAll("a[href], button, input:not([type=hidden]), select, textarea, [role=button], [role=link], [role=tab], [tabindex]:not([tabindex='-1'])")].filter((c) => { if (!visible(c)) return false; const r = c.getBoundingClientRect(); return r.width > 2 && r.height > 2; }).slice(0, 600);
  let ok24 = 0, ok44 = 0;
  const tiny = [], small = [];
  for (const c of controls) {
    const r = c.getBoundingClientRect();
    // inline text links inside a sentence are exempt from the minimum (WCAG 2.5.8)
    const inline = c.tagName === "A" && getComputedStyle(c).display === "inline" && c.parentElement && /^(P|LI|SPAN|TD)$/.test(c.parentElement.tagName);
    if (inline || (r.width >= 24 && r.height >= 24)) ok24++; else small.push({ c, r });
    if (inline || (r.width >= 44 && r.height >= 44)) ok44++;
  }
  // WCAG 2.5.8 spacing exception: an undersized target passes when a 24px circle on its
  // centre does not touch another target's circle (centres at least 24px apart)
  const centre = (r) => [r.left + r.width / 2, r.top + r.height / 2];
  const rects = controls.map((c) => c.getBoundingClientRect());
  for (const { c, r } of small) {
    const [x, y] = centre(r);
    const crowded = rects.some((o) => { if (o === r) return false; const [ox, oy] = centre(o); return o.width && Math.hypot(ox - x, oy - y) < 24 && !(ox === x && oy === y); });
    if (!crowded) ok24++; else tiny.push((c.textContent || c.getAttribute("aria-label") || c.tagName).trim().slice(0, 20) + ` ${round(r.width)}×${round(r.height)}`);
  }
  const n = Math.max(1, controls.length);
  add("targets", "touch targets", (ok24 / n) * 80 + (ok44 / n) * 20,
    [`${ok24} of ${controls.length} controls meet the 24 px minimum (size or spacing)`, `${ok44} reach the comfortable 44×44 px`, tiny[0] ? `smallest: ${tiny.slice(0, 2).join(", ")}` : ""],
    tiny.length ? "give icon buttons and small links at least 24×24 px of hit area (44 px on touch screens)" : "targets are generous; keep spacing between neighbours", 1, tiny.length > 0);

  // ---- 3. type ------------------------------------------------------------------------------------
  const sizeWeight = new Map();
  for (const t of texts) { const s = round(parseFloat(t.style.fontSize)); sizeWeight.set(s, (sizeWeight.get(s) || 0) + t.len); }
  const steps = [...sizeWeight.entries()].filter(([, w]) => w > words * 0.01).map(([s]) => s).sort((a, b) => a - b);
  const bodySize = [...sizeWeight.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || 16;
  const paras = [...document.querySelectorAll("p, li, article div")].filter((p) => visible(p) && (p.textContent || "").trim().length > 120).slice(0, 40);
  let lineLen = 0, lineH = 0, counted = 0;
  for (const p of paras) {
    const s = getComputedStyle(p); const size = parseFloat(s.fontSize) || 16;
    const lh = parseFloat(s.lineHeight) || size * 1.2;
    const lines = Math.max(1, Math.round(p.getBoundingClientRect().height / lh));
    // characters per rendered line; narrow cards with one short line do not count as "reading"
    if (lines >= 2) { lineLen += (p.textContent || "").trim().length / lines; counted++; }
    lineH += lh / size;
  }
  lineLen = counted ? lineLen / counted : 0;
  lineH = paras.length ? lineH / paras.length : 0;
  let typeScore = 100;
  if (bodySize < 14) typeScore -= 30; else if (bodySize < 16) typeScore -= 10;
  if (steps.length > 7) typeScore -= Math.min(30, (steps.length - 7) * 6);
  if (lineLen && (lineLen < 40 || lineLen > 95)) typeScore -= 20;
  if (lineH && (lineH < 1.3 || lineH > 2)) typeScore -= 15;
  add("type", "typography", typeScore,
    [`body text ${bodySize}px`, `${steps.length} distinct sizes in use (${steps.slice(0, 8).join(", ")})`, lineLen ? `paragraph lines ≈ ${round(lineLen)} characters` : "", lineH ? `line height ${lineH.toFixed(2)}` : ""],
    bodySize < 16 ? "set body text to 16px or more" : steps.length > 7 ? "collapse the type sizes onto one scale (5–6 steps, e.g. ratio 1.25)" : lineLen > 95 ? "cap reading width at about 70 characters" : "type system is coherent; keep one scale", 1, typeScore < 85);

  // ---- 4. hierarchy ----------------------------------------------------------------------------------
  const h1s = [...document.querySelectorAll("h1")].filter(visible);
  const heads = [...document.querySelectorAll("h1,h2,h3,h4,h5,h6")].filter(visible).map((h) => +h.tagName[1]);
  let skips = 0; for (let i = 1; i < heads.length; i++) if (heads[i] - heads[i - 1] > 1) skips++;
  const firstScreen = texts.filter((t) => { const r = t.el.getBoundingClientRect(); return r.top < vh && r.bottom > 0; });
  const largest = firstScreen.reduce((m, t) => Math.max(m, parseFloat(t.style.fontSize)), 0);
  const h1Size = h1s[0] ? parseFloat(getComputedStyle(h1s[0]).fontSize) : 0;
  const buttons = controls.filter((c) => { const r = c.getBoundingClientRect(); return r.top < vh && r.bottom > 0 && r.width > 60 && r.height > 28; });
  const filled = buttons.filter((b) => { const c = parse(getComputedStyle(b).backgroundColor); if (!c || c[3] < 0.6) return false; const mx = Math.max(c[0], c[1], c[2]), mn = Math.min(c[0], c[1], c[2]); return mx - mn > 40; });
  let hier = 100;
  if (h1s.length !== 1) hier -= 25;
  hier -= Math.min(25, skips * 8);
  if (h1Size && largest > h1Size * 1.15) hier -= 15;
  if (filled.length > 3) hier -= 15; else if (filled.length === 0 && buttons.length > 0) hier -= 5;
  add("hierarchy", "hierarchy", hier,
    [`${h1s.length} h1 on the page`, skips ? `${skips} skipped heading level(s)` : "heading levels in order", h1Size ? (largest > h1Size * 1.15 ? `something on the first screen is larger than the h1 (${round(largest)}px vs ${round(h1Size)}px)` : "the h1 leads the first screen") : "", `${filled.length} filled, coloured action(s) on the first screen`],
    h1s.length !== 1 ? "use exactly one h1 that names the page" : filled.length > 3 ? "keep one primary action per screen; make the others quiet" : skips ? "do not skip heading levels" : "one clear focal point; keep it", 1.2, hier < 85);

  // ---- 5. rhythm (spacing) -------------------------------------------------------------------------
  const spacings = [];
  for (const el of [...document.querySelectorAll("body *")].slice(0, 1500)) {
    if (!el.getBoundingClientRect().height) continue;
    const s = getComputedStyle(el);
    for (const v of [s.marginTop, s.marginBottom, s.paddingTop, s.paddingLeft, s.rowGap, s.columnGap]) { const px = parseFloat(v); if (px > 0 && px < 200) spacings.push(px); }
    if (spacings.length > 4000) break;
  }
  const onGrid = spacings.filter((v) => Math.abs(v / 4 - Math.round(v / 4)) < 0.13).length;
  const distinct = new Set(spacings.map(round)).size;
  const fewSpacings = spacings.length < 20; // too little layout to judge a rhythm
  add("rhythm", "spacing rhythm", fewSpacings ? 85 : (onGrid / spacings.length) * 75 + (distinct <= 12 ? 25 : distinct <= 20 ? 12 : 0),
    fewSpacings ? [`only ${spacings.length} spacing values: too little layout to judge`] : [`${round((onGrid / spacings.length) * 100)}% of spacings sit on a 4px grid`, `${distinct} distinct spacing values`],
    distinct > 20 || (spacings.length && onGrid / spacings.length < 0.7) ? "derive spacing from one scale (4, 8, 12, 16, 24, 32, 48)" : "spacing follows a rhythm; keep new components on the same scale", 0.8, !fewSpacings && (distinct > 20 || onGrid / spacings.length < 0.7));

  // ---- 6. shape -------------------------------------------------------------------------------------
  const radii = new Map(), shadows = new Set();
  for (const el of [...document.querySelectorAll("button, a, input, img, div, section, article, li")].slice(0, 1500)) {
    const s = getComputedStyle(el);
    const r = parseFloat(s.borderTopLeftRadius);
    if (r > 0) { const k = r >= 999 ? "pill" : String(round(r)); radii.set(k, (radii.get(k) || 0) + 1); }
    if (s.boxShadow && s.boxShadow !== "none") shadows.add(s.boxShadow.replace(/rgba?\([^)]*\)/g, "c"));
  }
  for (const c of controls) { const r = parseFloat(getComputedStyle(c).borderTopLeftRadius); if (r > 0) { const k = r >= 999 ? "pill" : String(round(r)); radii.set(k, Math.max(radii.get(k) || 0, 2)); } }
  const family = [...radii.entries()].filter(([, c]) => c >= 2).length;
  add("shape", "shape language", 100 - Math.max(0, family - 4) * 10 - Math.max(0, shadows.size - 4) * 8,
    [`${family} corner radii in regular use (${[...radii.keys()].slice(0, 6).join(", ")})`, `${shadows.size} distinct shadow styles`],
    family > 4 ? "settle on 2–3 corner radii (small, medium, pill) that belong together" : shadows.size > 4 ? "use one light source: 2–3 elevation shadows" : "one coherent shape family", 0.6, family > 4 || shadows.size > 4);

  // ---- 7. colour ------------------------------------------------------------------------------------
  const hueSet = new Map();
  const hueOf = (c) => { const [r, g, b] = c.map((v) => v / 255); const mx = Math.max(r, g, b), mn = Math.min(r, g, b); if (mx - mn < 0.18) return null; let h = mx === r ? (g - b) / (mx - mn) : mx === g ? 2 + (b - r) / (mx - mn) : 4 + (r - g) / (mx - mn); h = ((h * 60) + 360) % 360; return Math.round(h / 30); };
  for (const t of texts.slice(0, 400)) {
    for (const v of [t.style.color, getComputedStyle(t.el).backgroundColor, t.style.borderTopColor]) { const c = parse(v); if (c && c[3] > 0.3) { const h = hueOf(c); if (h !== null) hueSet.set(h, (hueSet.get(h) || 0) + 1); } }
  }
  for (const b of controls) { const c = parse(getComputedStyle(b).backgroundColor); if (c && c[3] > 0.5) { const h = hueOf(c); if (h !== null) hueSet.set(h, (hueSet.get(h) || 0) + 3); } }
  const accents = [...hueSet.entries()].filter(([, w]) => w >= 3).length;
  add("colour", "colour system", accents <= 2 ? 100 : accents <= 4 ? 80 : accents <= 6 ? 60 : 40,
    [`${accents} accent hue(s) in regular use`, accents <= 2 ? "one accent leads the eye" : "several accents compete for attention"],
    accents > 3 ? "keep one action colour; use the others only for status (success, warning, error)" : "palette is disciplined", 0.8, accents > 3);

  // ---- 8. access semantics -------------------------------------------------------------------------
  const imgs = [...document.images].filter((i) => visible(i) && i.width * i.height > 900);
  const alt = imgs.filter((i) => i.hasAttribute("alt")).length;
  const fields = [...document.querySelectorAll("input:not([type=hidden]):not([type=submit]):not([type=button]), select, textarea")].filter(visible);
  const labelled = fields.filter((f) => (f.labels && f.labels.length) || f.getAttribute("aria-label") || f.getAttribute("aria-labelledby") || f.getAttribute("title")).length;
  const lang = !!document.documentElement.getAttribute("lang");
  const landmarks = !!document.querySelector("main, [role=main]") + !!document.querySelector("nav, [role=navigation]");
  // focus styles: rules that remove the outline on :focus without a :focus-visible or shadow replacement
  let outlineKilled = 0, readable = 0, reducedRules = 0;
  for (const sheet of [...document.styleSheets].slice(0, 40)) {
    let rules; try { rules = sheet.cssRules; readable++; } catch { continue; }
    const walk = (list) => { for (const r of list) {
      if (r.media && /prefers-reduced-motion/.test(r.media.mediaText)) reducedRules++;
      if (r.cssRules) walk(r.cssRules);
      // ":focus:not(:focus-visible) { outline: none }" keeps keyboard focus visible: that is correct, not a removal
      if (r.selectorText && /:focus(?!-visible|-within)/.test(r.selectorText) && !/:not\(:focus-visible\)/.test(r.selectorText) && /outline:\s*(none|0)/.test(r.cssText) && !/box-shadow|border/.test(r.cssText)) outlineKilled++;
    } };
    try { walk(rules); } catch {}
  }
  let acc = 100;
  if (imgs.length) acc -= ((imgs.length - alt) / imgs.length) * 30;
  if (fields.length) acc -= ((fields.length - labelled) / fields.length) * 30;
  if (!lang) acc -= 10;
  acc -= (2 - landmarks) * 7;
  if (outlineKilled) acc -= Math.min(20, outlineKilled * 7);
  add("access", "accessibility semantics", acc,
    [imgs.length ? `${alt} of ${imgs.length} images have alt text` : "no content images", fields.length ? `${labelled} of ${fields.length} fields have labels` : "", lang ? "page language set" : "no page language", outlineKilled ? `${outlineKilled} rule(s) remove the focus outline` : "focus outline kept"],
    imgs.length > alt ? "give every image an alt (empty alt=\"\" for decoration)" : fields.length > labelled ? "label every field" : !lang ? "set <html lang>" : outlineKilled ? "keep a visible :focus-visible style" : "semantics are in good order", 1.1, acc < 95);

  // ---- 9. motion ------------------------------------------------------------------------------------
  const anims = document.getAnimations ? document.getAnimations() : [];
  const running = anims.filter((a) => a.playState === "running");
  const endless = running.filter((a) => { const t = a.effect && a.effect.getTiming && a.effect.getTiming(); return t && t.iterations === Infinity; });
  const autoplay = [...document.querySelectorAll("video[autoplay]")].filter((v) => !v.muted || v.loop).length;
  let mot = 100;
  if (endless.length) mot -= Math.min(30, endless.length * 8);
  if (running.length > 12) mot -= 15;
  if (running.length && !reducedRules && readable) mot -= 20;
  if (autoplay) mot -= 15;
  add("motion", "motion", mot,
    [`${running.length} animation(s) running at rest`, endless.length ? `${endless.length} loop forever` : "", readable ? (reducedRules ? "honours prefers-reduced-motion" : "no reduced-motion rules found") : "stylesheets not readable (cross-origin)", autoplay ? `${autoplay} autoplaying video(s)` : ""],
    endless.length ? "stop endless loops once their message is given; motion should follow a cause" : (running.length && !reducedRules) ? "add a prefers-reduced-motion variant that keeps meaning without movement" : "motion is restrained", 0.7, mot < 85);

  // ---- 10. load (choices and interruptions) ------------------------------------------------------
  const firstChoices = controls.filter((c) => { const r = c.getBoundingClientRect(); return r.top < vh && r.bottom > 0; }).length;
  const blocking = [...document.querySelectorAll("body *")].slice(0, 3000).filter((el) => { const s = getComputedStyle(el); if (s.position !== "fixed" || s.display === "none" || s.visibility === "hidden") return false; const r = el.getBoundingClientRect(); return r.width * r.height > vw * vh * 0.35; }).length;
  add("load", "cognitive load", 100 - Math.max(0, firstChoices - 25) * 1.2 - blocking * 25,
    [`${firstChoices} choices on the first screen`, blocking ? `${blocking} overlay(s) cover the page` : "nothing blocks the page"],
    blocking ? "let people reach the content before asking for anything" : firstChoices > 40 ? "group or hide secondary choices; fewer options decide faster (hick-hyman)" : "the first screen asks little of people", 1, blocking > 0 || firstChoices > 40);

  // ---- overall -----------------------------------------------------------------------------------------
  const wsum = dims.reduce((s, d) => s + d.weight, 0);
  const score = round(dims.reduce((s, d) => s + d.score * d.weight, 0) / wsum);
  const sorted = dims.slice().sort((a, b) => a.score - b.score);
  const grade = score >= 90 ? "A" : score >= 80 ? "B" : score >= 70 ? "C" : score >= 60 ? "D" : "E";
  const confidence = texts.length < 15 ? "low" : readable === 0 ? "medium" : "high";
  return {
    version: VERSION, host: location.hostname, url: location.href, score, grade, confidence,
    strengths: sorted.slice(-2).reverse().map((d) => d.label),
    fixes: sorted.filter((d) => d.needs).slice(0, 3).map((d) => ({ label: d.label, score: d.score, fix: d.fix })),
    dimensions: dims.map(({ key, label, score, evidence, fix, needs }) => ({ key, label, score, evidence, fix, needs })),
    samples: { texts: texts.length, controls: controls.length, stylesheetsReadable: readable },
    lowContrast: worst.slice(0, 5).map(([cr, text, need, where, fg, bg]) => ({ text, where, ratio: +cr.toFixed(2), need, fg: "rgb(" + fg.slice(0, 3).map(Math.round).join(", ") + ")", bg: "rgb(" + bg.slice(0, 3).map(Math.round).join(", ") + ")" })),
    ms: round(performance.now() - T0),
  };
})();
