// Isolated-world bridge for profile.js: fetches the toggle from background
// and forwards changes so a popup switch flips the panel on live.
(() => {
  "use strict";
  if (window.__noahShieldProfileBridge) return;
  window.__noahShieldProfileBridge = true;
  const api = (typeof chrome !== "undefined" && chrome.runtime) ? chrome : (typeof browser !== "undefined" ? browser : null);
  if (!api || !api.runtime || !api.runtime.sendMessage) return;

  let cached = null;
  // The MAIN-world script announces a nonce at document_start, before any
  // page script can listen; every event to it carries that nonce, and one
  // without it is a page's forgery and is ignored.
  let nonce = null;
  const channel = (name) => name + ":" + nonce;
  const UN_KEY = "profileHandles";
  const UN_MAX_IDS = 3000;
  let chain = Promise.resolve();
  // Writes are serialized so two profile loads cannot overwrite each other.
  const queue = (job) => { chain = chain.then(job).catch(() => {}); return chain; };
  const load = async () => {
    try { const got = await api.storage.local.get(UN_KEY); return (got && got[UN_KEY]) || {}; } catch { return {}; }
  };
  const save = async (map) => {
    const ids = Object.keys(map);
    if (ids.length > UN_MAX_IDS) for (const id of ids.slice(0, ids.length - UN_MAX_IDS)) delete map[id];
    try { await api.storage.local.set({ [UN_KEY]: map }); } catch {}
  };
  window.addEventListener("noah-profile-hello", (event) => {
    if (nonce !== null) return;
    nonce = String(event.detail || "");
    onPaired();
  });
  try { window.dispatchEvent(new CustomEvent("noah-profile-bridge-ready")); } catch {}
  function onPaired() {
    if (cached) send(cached);
    // panel position / collapsed state: worker memo for this browser session
    const MEMO_KEYS = ["noah-profile-pos", "noah-profile-collapsed"];
    window.addEventListener(channel("noah-profile-memo-set"), (event) => {
      const d = event.detail || {};
      if (!MEMO_KEYS.includes(d.key)) return;
      api.runtime.sendMessage({ type: "memo.set", key: d.key, value: d.value }, () => { void api.runtime.lastError; });
    });
    Promise.all(MEMO_KEYS.map((key) => new Promise((resolve) => api.runtime.sendMessage({ type: "memo.get", key }, (r) => { void api.runtime.lastError; resolve([key, r && r.value]); }))))
      .then((pairs) => {
        const detail = {};
        for (const [key, value] of pairs) if (value !== null && value !== undefined) detail[key] = value;
        try { window.dispatchEvent(new CustomEvent(channel("noah-profile-memo"), { detail })); } catch {}
      });
    // Username history lives here, in extension storage, never in the page.
    window.addEventListener(channel("noah-profile-un-record"), (event) => {
      const d = event.detail || {};
      const id = typeof d.id === "string" ? d.id.slice(0, 32) : "";
      const h = typeof d.h === "string" ? d.h.slice(0, 64) : "";
      if (!/^\d{1,32}$/.test(id) || !/^[A-Za-z0-9_]{1,64}$/.test(h)) return;
      queue(() => recordHandle(id, h));
    });
    window.addEventListener(channel("noah-profile-un-import"), (event) => {
      const d = event.detail;
      if (!d || typeof d !== "object") return;
      queue(async () => {
        const stored = await load();
        for (const [id, list] of Object.entries(d).slice(0, 2000)) {
          if (!/^\d{1,32}$/.test(id) || !Array.isArray(list)) continue;
          const clean = list.filter((e) => e && typeof e.h === "string" && /^[A-Za-z0-9_]{1,64}$/.test(e.h)).slice(-10).map((e) => ({ h: e.h, d: String(e.d || "").slice(0, 10) }));
          if (clean.length && !stored[id]) stored[id] = clean;
        }
        await save(stored);
      });
    });
  }
  async function recordHandle(id, h) {
    const map = await load();
    const list = map[id] || [];
    const last = list[list.length - 1];
    if (!last || last.h !== h) {
      list.push({ h, d: new Date().toISOString().slice(0, 10) });
      delete map[id];
      map[id] = list.slice(-10);
      await save(map);
    }
    if (nonce !== null) try { window.dispatchEvent(new CustomEvent(channel("noah-profile-un-history"), { detail: { id, list: map[id] } })); } catch {}
  }
  function send(config) {
    cached = config;
    if (nonce === null) return;
    try { window.dispatchEvent(new CustomEvent(channel("noah-profile-config"), { detail: config })); } catch {}
  }

  api.runtime.sendMessage({ type: "profile.config" }, (reply) => {
    if (api.runtime.lastError || !reply) return;
    send(reply.profile || { enabled: true });
  });

  if (api.runtime.onMessage && api.runtime.onMessage.addListener) {
    api.runtime.onMessage.addListener((message) => {
      if (!message || message.type !== "profile.set") return;
      send(message.profile || { enabled: true });
    });
  }
})();
