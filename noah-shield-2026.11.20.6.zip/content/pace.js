// Pace: one place for the content scripts to watch the page without slowing
// it down. Every script used to run its own MutationObserver and rescan the
// whole document on every change, some with no delay at all; on busy pages
// (feeds, editors, video sites) that was dozens of full-page scans a second,
// each forcing layout. This file gives them a shared, budgeted watcher:
//
//   - a callback runs at most once per `delay` ms, in idle time;
//   - nothing runs while the tab is hidden;
//   - once the page has settled (20 s after load) the delay grows, because a
//     banner or a wall shows up early and a feed scrolling forever does not;
//   - the shield's own elements never trigger a rescan, so a script cannot
//     wake itself up by touching the page.
//
// Loaded first, at document_start, in the isolated world shared by all of
// the shield's content scripts. Scripts fall back to their own timer if it
// is somehow missing.
(() => {
  "use strict";
  if (window.__noahPace) return;

  let lastInput = 0;
  const noteInput = () => { lastInput = Date.now(); };
  for (const type of ["pointerdown", "keydown", "touchstart", "wheel"]) {
    window.addEventListener(type, noteInput, { capture: true, passive: true });
  }

  const OWN = /^(NOAH-SHIELD|NS-[0-9A-F]{8})-/;
  const isOwn = (node) => {
    let element = node && node.nodeType === 1 ? node : node && node.parentElement;
    for (let depth = 0; element && depth < 6; depth++, element = element.parentElement) {
      // hasAttribute, not dataset: dataset builds a new wrapper object per call
      if (OWN.test(element.tagName) || element.id === "__noah_cognition_pill" || (element.hasAttribute && element.hasAttribute("data-noah"))) return true;
    }
    return false;
  };

  const idle = (fn, timeout) => {
    if (typeof requestIdleCallback === "function") requestIdleCallback(() => fn(), { timeout });
    else setTimeout(fn, 0);
  };

  const started = Date.now();

  // watch(callback, options) -> { stop() }
  //   delay: ms between runs while the page is young (default 1000)
  //   settledDelay: ms between runs after `settleAfter` ms (default 4000)
  //   settleAfter: ms after which the page counts as settled (default 20000)
  //   target: node to observe (default documentElement)
  //   attributes: watch attribute changes too (default false; expensive)
  //   maxRuns: stop for good after this many runs (default unlimited)
  // Watchers on the whole document with childList only (the common case)
  // share ONE MutationObserver: the browser queues each batch once and the
  // "is this the shield's own node?" check runs once per batch, not once per
  // script. Watchers with a custom target or attributes keep their own.
  const shared = new Set();
  let sharedObserver = null;
  const onShared = (mutations) => {
    // nobody is waiting for a wake-up (all already scheduled): skip the check entirely
    let anyIdle = false;
    for (const subscriber of shared) if (subscriber.idle()) { anyIdle = true; break; }
    if (!anyIdle) return;
    let relevant = false;
    for (const mutation of mutations) {
      if (!isOwn(mutation.target)) { relevant = true; break; }
    }
    if (!relevant) return;
    for (const subscriber of shared) subscriber.poke();
  };
  const startShared = () => {
    if (sharedObserver) return;
    if (!document.documentElement) { document.addEventListener("readystatechange", startShared, { once: true }); return; }
    sharedObserver = new MutationObserver(onShared);
    sharedObserver.observe(document.documentElement, { childList: true, subtree: true });
  };

  function watch(callback, options = {}) {
    const delay = options.delay ?? 1000;
    const settledDelay = options.settledDelay ?? Math.max(delay, 4000);
    const settleAfter = options.settleAfter ?? 20000;
    const maxRuns = options.maxRuns ?? Infinity;
    let pending = null;
    let runs = 0;
    let stopped = false;
    const run = () => {
      pending = null;
      if (stopped) return;
      if (document.hidden) { pending = setTimeout(run, 5000); return; }
      runs++;
      idle(() => { try { callback(); } catch { /* a script's problem, not the page's */ } }, 1500);
      if (runs >= maxRuns) stop();
    };
    const poke = () => {
      if (pending || stopped) return;
      const wait = Date.now() - started > settleAfter ? settledDelay : delay;
      pending = setTimeout(run, wait);
    };
    const own = Boolean(options.target || options.attributes);
    let observer = null;
    const subscriber = { poke, idle: () => !pending && !stopped };
    if (own) {
      observer = new MutationObserver((mutations) => {
        if (pending || stopped) return;
        for (const mutation of mutations) {
          if (!isOwn(mutation.target)) { poke(); return; }
        }
      });
      const target = options.target || document.documentElement;
      if (target) observer.observe(target, { childList: true, subtree: true, attributes: Boolean(options.attributes), attributeFilter: options.attributeFilter });
    } else {
      shared.add(subscriber);
      startShared();
    }
    const stop = () => {
      stopped = true;
      if (observer) observer.disconnect();
      shared.delete(subscriber);
      if (!shared.size && sharedObserver) { sharedObserver.disconnect(); sharedObserver = null; }
      if (pending) clearTimeout(pending);
      pending = null;
    };
    return { stop };
  }

  window.__noahPace = {
    watch,
    idle,
    isOwn,
    // Did the person click, type or scroll within the last `ms` milliseconds?
    inputWithin: (ms) => lastInput && Date.now() - lastInput < ms,
    lastInput: () => lastInput,
    age: () => Date.now() - started,
  };
})();
