// The relationship map docked as a sidebar on a search page: the fallback for browsers that will not
// open their own side panel from a page click. The page itself is narrowed to make room, so the map
// sits beside the results instead of covering them. Injected by the worker only when the handle is
// pressed; lives in a closed shadow root (the engine's styles cannot reach it, the page cannot read
// it); every fetch happens in the worker (relate.map).
"use strict";
(() => {
  const api = globalThis.chrome ?? globalThis.browser;
  if (globalThis.__noahRelate) return;
  const Shield = globalThis.Shield;
  const WIDTH = "min(440px, 46vw)";
  const state = { seeds: [], expand: [], name: "", host: null, view: null, open: false, busy: false, saved: null };

  function send(message) {
    return new Promise((resolve) => api.runtime.sendMessage(message, (r) => { void api.runtime.lastError; resolve(r || { error: "no answer from noah shield" }); }));
  }
  const reduced = () => { try { return matchMedia("(prefers-reduced-motion: reduce)").matches; } catch { return false; } };

  function build() {
    const host = document.createElement("div");
    host.style.cssText = `all:initial;position:fixed;top:0;right:0;height:100vh;width:${WIDTH};z-index:2147483001`;
    const shadow = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
      :host{all:initial}
      .panel{box-sizing:border-box;height:100%;overflow:auto;overscroll-behavior:contain;background:rgba(9,15,12,.97);border-left:1px solid #24332b;padding:14px 14px 28px;color:#e9e4d6;font:13px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;display:flex;flex-direction:column;gap:12px;scrollbar-width:thin;scrollbar-color:#3c5245 transparent}
      header{display:flex;align-items:flex-start;gap:8px}
      h2{margin:0;font:400 20px/1.2 Georgia,"Times New Roman",serif;flex:1}
      h2 small{display:block;font:400 12px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif;color:#b9b6a6;margin-top:2px}
      button.x{min-height:44px;min-width:44px;border-radius:10px;border:1px solid #24332b;background:transparent;color:#e9e4d6;font-size:20px;line-height:1;cursor:pointer}
      button.x:hover,button.x:focus-visible{border-color:#8fc79a;outline:none}
    `;
    const panel = document.createElement("section");
    panel.className = "panel";
    panel.setAttribute("role", "complementary");
    panel.setAttribute("aria-label", "noah shield relationship map");
    panel.innerHTML = `<header><h2>relations<small></small></h2><button class="x" type="button" aria-label="close the map">×</button></header><div class="view"></div>`;
    shadow.append(style, panel);
    const close = panel.querySelector(".x");
    close.addEventListener("click", hide);
    panel.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.stopPropagation(); hide(); } });
    state.view = Shield.relateView.create(panel.querySelector(".view"), {
      onExpand: (site, button) => { if (!state.expand.includes(site)) state.expand.push(site); run(button); },
      onHistory: (site) => send({ type: "relate.history", host: site }),
      onOpen: (url) => window.open(url, "_blank", "noopener,noreferrer"),
    });
    document.documentElement.append(host);
    state.host = host; state.panel = panel; state.close = close; state.sub = panel.querySelector("h2 small");
  }

  async function run(button) {
    if (state.busy) return;
    state.busy = true;
    if (button) button.setAttribute("aria-busy", "true");
    if (!state.view.graph) state.view.busy("reading " + state.seeds.length + " results…");
    const g = await send({ type: "relate.map", seeds: state.seeds.slice(0, 16), expand: state.expand, name: state.name });
    state.busy = false;
    if (button) button.removeAttribute("aria-busy");
    if (!g || g.error) { state.view.error((g && g.error) || "the map could not be built"); return; }
    state.view.set(g);
  }

  // dock: the page gives up the panel's width on the right, so nothing is covered
  function dock(on) {
    const html = document.documentElement;
    if (on) {
      if (!state.saved) state.saved = { mr: html.style.getPropertyValue("margin-right"), mrp: html.style.getPropertyPriority("margin-right"), ov: html.style.getPropertyValue("overflow-x") };
      html.style.setProperty("margin-right", WIDTH, "important");
      html.style.setProperty("overflow-x", "hidden", "important");
    } else if (state.saved) {
      html.style.removeProperty("margin-right"); html.style.removeProperty("overflow-x");
      if (state.saved.mr) html.style.setProperty("margin-right", state.saved.mr, state.saved.mrp);
      if (state.saved.ov) html.style.setProperty("overflow-x", state.saved.ov);
      state.saved = null;
    }
  }
  function show() {
    if (!state.host) build();
    state.host.style.display = "";
    state.open = true;
    dock(true);
    if (!reduced() && state.panel.animate) state.panel.animate([{ transform: "translateX(100%)" }, { transform: "none" }], { duration: 280, easing: "cubic-bezier(.2,.8,.2,1)" });
    state.close.focus({ preventScroll: true });
  }
  function hide() {
    if (!state.host) return;
    state.open = false;
    const done = () => { if (!state.open) { state.host.style.display = "none"; dock(false); } };
    if (!reduced() && state.panel.animate) state.panel.animate([{ transform: "none" }, { transform: "translateX(100%)" }], { duration: 200, easing: "cubic-bezier(.4,0,1,1)" }).finished.then(done, done);
    else done();
    if (typeof globalThis.__noahRelateClosed === "function") globalThis.__noahRelateClosed();
  }

  globalThis.__noahRelate = {
    open(seeds, name) {
      const fresh = String(name || "") !== state.name || !state.seeds.length;
      if (fresh) { state.seeds = []; state.expand = []; }
      state.name = String(name || "").slice(0, 80);
      for (const s of seeds || []) if (!state.seeds.some((x) => x.url === s.url)) state.seeds.push(s);
      show();
      state.sub.textContent = state.name ? `results for “${state.name}”: names ↔ sites ↔ infrastructure` : "names ↔ sites ↔ infrastructure";
      if (fresh || !state.view.graph) run();
    },
    toggle() { state.open ? hide() : show(); },
    get isOpen() { return state.open; },
  };
})();
