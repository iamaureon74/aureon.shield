// Page-fact collector for the passive site audit.
//
// Reads only the page the browser already loaded — never probes, never
// touches another origin. On request it reports the facts the header audit
// cannot see from headers alone: resources pulled over http on an https page,
// forms that send passwords off-origin or in the clear, third-party scripts
// with no Subresource Integrity, and whether a CSP was set via <meta>.
"use strict";
(() => {
  if (window.__noahAuditFacts) return;
  window.__noahAuditFacts = true;
  const api = (typeof browser !== "undefined" && browser.runtime) ? browser : chrome;

  function collect() {
    const https = location.protocol === "https:";
    const here = location.hostname.replace(/^www\./, "");
    const isHttp = (u) => { try { return new URL(u, location.href).protocol === "http:"; } catch { return false; } };
    const sameSite = (u) => { try { return new URL(u, location.href).hostname.replace(/^www\./, "").endsWith(here); } catch { return true; } };

    const mixedContent = [];
    if (https) for (const node of document.querySelectorAll("script[src],link[href],img[src],iframe[src],video[src],audio[src],source[src],embed[src],object[data]")) {
      const url = node.getAttribute("src") || node.getAttribute("href") || node.getAttribute("data") || "";
      if (url && isHttp(url)) mixedContent.push(url.slice(0, 120));
      if (mixedContent.length >= 20) break;
    }

    const tokenField = /csrf|xsrf|_token|authenticity|antiforgery|requestverification|nonce/i;
    const forms = [];
    for (const form of document.querySelectorAll("form")) {
      const action = form.getAttribute("action") || location.href;
      const hasToken = [...form.querySelectorAll("input[name]")].some((i) => tokenField.test(i.getAttribute("name") || ""));
      forms.push({ action: String(action).slice(0, 120), method: (form.getAttribute("method") || "get").toLowerCase(), https: !isHttp(action), crossSite: !sameSite(action), hasPassword: !!form.querySelector('input[type="password"]'), hasToken });
      if (forms.length >= 30) break;
    }

    // links carrying a redirect-shaped parameter (open-redirect surface)
    const redirectParam = /^(next|url|redirect|redirect_uri|redirecturl|return|returnurl|return_to|returnto|goto|dest|destination|continue|target|forward|out|away|link|u|r)$/i;
    const links = [];
    for (const a of document.querySelectorAll("a[href]")) {
      const href = a.getAttribute("href") || "";
      if (!/[?&]/.test(href)) continue;
      try { const u = new URL(href, location.href); for (const [k, v] of u.searchParams) { if (redirectParam.test(k) && /^(https?:)?\/\//i.test(decodeURIComponent(v))) { links.push(href.slice(0, 140)); break; } } } catch {}
      if (links.length >= 10) break;
    }

    // clickfix lure: run-dialog + paste/verification instructions in the visible text
    let clickfix = false;
    try {
      const text = (document.body ? document.body.innerText : "").slice(0, 20000).toLowerCase();
      const runDialog = /win(dows)?\s*(key)?\s*\+\s*r\b/.test(text) || /⊞\s*\+?\s*r\b/.test(text) || /open (the )?run (dialog|box)/.test(text);
      const paste = /ctrl\s*\+\s*v/.test(text) || /press\s+(enter|paste)/.test(text) || /paste (it|the|this)/.test(text);
      const lure = /verify (you are |you're )?(a )?human|i'?m not a robot|not a robot|verification (code|required|steps)|to (continue|proceed|fix|verify)/.test(text);
      clickfix = runDialog && (paste || lure);
    } catch {}
    // a password field outside any <form> still submits somewhere
    if (!forms.some((f) => f.hasPassword) && document.querySelector('input[type="password"]')) forms.push({ action: location.href, https, crossSite: false, hasPassword: true });

    const externalScripts = [];
    for (const s of document.querySelectorAll("script[src]")) {
      const src = s.getAttribute("src") || "";
      if (/^https?:\/\//.test(src) && !sameSite(src)) externalScripts.push({ src: src.slice(0, 140), integrity: s.getAttribute("integrity") || "" });
      if (externalScripts.length >= 40) break;
    }

    // every distinct domain / subdomain this page pulled a resource from,
    // with how it was reached — so the audit can grade the page and its sub/domains.
    const hostMap = new Map();
    const note = (u) => {
      try {
        const url = new URL(u, location.href);
        if (!/^https?:$/.test(url.protocol)) return;
        const h = url.hostname.replace(/^www\./, "");
        const row = hostMap.get(h) || { host: h, https: true, thirdParty: !h.endsWith(here) && !here.endsWith(h) };
        if (url.protocol === "http:") row.https = false;
        hostMap.set(h, row);
      } catch {}
    };
    note(location.href);
    for (const node of document.querySelectorAll("script[src],link[href],img[src],iframe[src],video[src],audio[src],source[src],embed[src],object[data]")) {
      note(node.getAttribute("src") || node.getAttribute("href") || node.getAttribute("data") || "");
      if (hostMap.size >= 80) break;
    }
    const hosts = [...hostMap.values()];

    // serialized-object exposure in page storage (CWE-502), classified locally.
    // only the serializer kind and the key are reported — never the value.
    const sigs = [
      ["node-serialize", (s) => s.includes("_$$ND_FUNC$$_")],
      ["java", (s) => s.startsWith("rO0AB")],
      ["php-object", (s) => /O:\d+:"/.test(s)],
      ["python-pickle", (s) => s.startsWith("gASV") || s.startsWith("gAJ") || s.startsWith("gAN")],
      ["dotnet-viewstate", (s) => s.startsWith("/wEP") || s.startsWith("/wEW")],
    ];
    const classify = (v) => { const s = String(v || ""); if (s.length < 5) return null; for (const [kind, t] of sigs) { try { if (t(s)) return kind; } catch {} } return null; };
    const serialStorage = [];
    for (const [area, store] of [["localStorage", (() => { try { return localStorage; } catch { return null; } })()], ["sessionStorage", (() => { try { return sessionStorage; } catch { return null; } })()]]) {
      if (!store) continue;
      try { for (let i = 0; i < store.length && serialStorage.length < 20; i++) { const key = store.key(i); const kind = classify(store.getItem(key)); if (kind) serialStorage.push({ area, key: String(key).slice(0, 40), kind }); } } catch {}
    }
    // asp.net viewstate integrity signal
    let viewstate = null;
    const vs = document.querySelector('input[name="__VIEWSTATE"]');
    if (vs) viewstate = { present: true, protected: !!document.querySelector('input[name="__VIEWSTATEGENERATOR"]') && !/^\/wEP/.test(vs.value || "") };

    const metaCsp = !!document.querySelector('meta[http-equiv="Content-Security-Policy" i]');
    return Object.assign({ https, host: here, mixedContent, forms, externalScripts, metaCsp, hosts, serialStorage, viewstate, links, textSignals: { clickfix } }, patternFacts(here, sameSite, isHttp));
  }

  // Facts for the shepherd pattern engine (lib/sec/patterns.js). Read-only;
  // secrets are reduced to a kind and a masked sample in the worker, storage
  // values never leave this function — only the key name and token shape do.
  function patternFacts(here, sameSite, isHttp) {
    const out = {};
    const body = document.body;
    out.pageText = body ? (body.innerText || "").slice(0, 60000) : "";
    // inline scripts (capped) and every script url
    let budget = 1500000;
    out.scriptTexts = [];
    for (const s of document.querySelectorAll("script:not([src])")) {
      const type = (s.getAttribute("type") || "").toLowerCase();
      if (type && !/javascript|module|^$/.test(type) && !/json/.test(type)) continue;
      const text = (s.textContent || "").slice(0, 300000);
      if (!text.trim()) continue;
      budget -= text.length;
      if (budget < 0) break;
      out.scriptTexts.push({ where: "inline script " + (out.scriptTexts.length + 1), text });
      if (out.scriptTexts.length >= 40) break;
    }
    out.scriptSrcs = [...document.querySelectorAll("script[src]")].map((s) => { try { return new URL(s.getAttribute("src"), location.href).href; } catch { return ""; } }).filter(Boolean).slice(0, 80);
    out.sameOriginScripts = out.scriptSrcs.filter((u) => { try { return new URL(u).origin === location.origin; } catch { return false; } }).slice(0, 8);
    // html comments
    let comments = "";
    try {
      const walker = document.createTreeWalker(document.documentElement, NodeFilter.SHOW_COMMENT);
      for (let n = walker.nextNode(), i = 0; n && i < 400 && comments.length < 100000; n = walker.nextNode(), i++) comments += n.nodeValue + "\n";
    } catch {}
    out.commentsText = comments;
    // tokens in storage: key name + shape only
    const jwt = /^eyJ[\w-]{8,}\.eyJ[\w-]{8,}\.[\w-]*$/;
    out.storageTokens = [];
    for (const [area, getStore] of [["localStorage", () => localStorage], ["sessionStorage", () => sessionStorage]]) {
      try {
        const store = getStore();
        for (let i = 0; i < store.length && out.storageTokens.length < 10; i++) {
          const key = store.key(i);
          const value = String(store.getItem(key) || "");
          let kind = jwt.test(value) ? "JWT" : "";
          if (!kind && /(access|id|refresh|auth|session)[_-]?token|bearer/i.test(key) && value.length >= 16) kind = "token";
          if (!kind && value.length < 20000 && /"(access_token|id_token|refresh_token)"\s*:\s*"/.test(value)) kind = "token object";
          if (kind) out.storageTokens.push({ area, key: String(key).slice(0, 40), kind });
        }
      } catch {}
    }
    // tokens in the address
    out.urlTokens = [];
    try {
      for (const part of [location.search.slice(1), location.hash.slice(1)]) for (const kv of part.split("&")) {
        const k = decodeURIComponent(kv.split("=")[0] || "");
        if (/^(access_token|id_token|refresh_token|token|auth|apikey|api_key|jwt)$/i.test(k) && (kv.split("=")[1] || "").length >= 12) out.urlTokens.push(k + " in the " + (part === location.hash.slice(1) ? "fragment" : "query"));
      }
    } catch {}
    // parameters shaped like file paths or urls-to-fetch, on this page's address and its links
    const pathName = /^(file|filename|path|page|template|tpl|include|inc|doc|document|folder|dir|load|read|view|lang)$/i;
    const fetchName = /^(url|uri|feed|image_url|imageurl|img|src|source|callback|webhook|proxy|fetch|endpoint|host|remote|link_url)$/i;
    out.pathParams = []; out.fetchParams = [];
    const hrefs = [location.href].concat([...document.querySelectorAll("a[href],form[action]")].slice(0, 1500).map((a) => a.getAttribute("href") || a.getAttribute("action") || ""));
    for (const href of hrefs) {
      if (!/[?&]/.test(href)) continue;
      try {
        const u = new URL(href, location.href);
        if (u.origin !== location.origin) continue;
        for (const [k, v] of u.searchParams) {
          const val = decodeURIComponent(v || "");
          if (pathName.test(k) && /(\/|\\|\.\w{2,4}$)/.test(val) && out.pathParams.length < 6) out.pathParams.push(k + "=" + val.slice(0, 60));
          if (fetchName.test(k) && /^(https?:)?\/\//i.test(val) && out.fetchParams.length < 6) out.fetchParams.push(k + "=" + val.slice(0, 60));
        }
      } catch {}
    }
    out.pathParams = [...new Set(out.pathParams)];
    out.fetchParams = [...new Set(out.fetchParams)];
    // uploads
    out.uploads = [];
    for (const form of document.querySelectorAll("form")) {
      if (!form.querySelector('input[type="file"]')) continue;
      const action = form.getAttribute("action") || location.href;
      out.uploads.push({ action: String(action).slice(0, 120), https: !isHttp(action), crossSite: !sameSite(action) });
    }
    // second-factor and passkey signals
    out.authSignals = {
      otp: !!document.querySelector('input[autocomplete~="one-time-code" i], input[name*="otp" i], input[name*="totp" i], input[name*="2fa" i]'),
      passkey: !!document.querySelector('input[autocomplete~="webauthn" i]') || /\bpasskey|sign in with a security key\b/i.test(out.pageText.slice(0, 20000)),
    };
    const frames = [...document.querySelectorAll("iframe[src]")].filter((f) => !sameSite(f.getAttribute("src") || ""));
    out.sandboxedFrames = frames.length > 0 && frames.every((f) => f.hasAttribute("sandbox"));
    // instructions aimed at AI agents, visible or hidden
    out.promptInjection = promptInjection();
    // url parameters whose value carries markup characters (for the worker's reflection check)
    out.markupParams = [];
    try { for (const [k, v] of new URL(location.href).searchParams) if (/[<>"']/.test(v) && v.length >= 3 && v.length <= 200) out.markupParams.push({ param: k.slice(0, 40), value: v }); } catch {}
    return out;
  }

  const AGENT = /(ignore (all |any )?(the )?(previous|prior|above|earlier) (instructions|prompts?|messages)|disregard (all |your |the )?(previous |prior )?(rules|instructions|guidelines)|you are (now )?(an? )?(ai|assistant|chatbot|language model|llm|agent)\b|as an ai (agent|assistant|model)|(new|updated|real) system prompt|system:\s*you|<\|im_start\|>|\[INST\]|do not (tell|inform|reveal to|mention (this )?to) the user|(ai|llm|assistant|agent)s?,? (must|should) (now )?(ignore|instead|always|never|send|reply|navigate|click|output)|when (an? )?(ai|llm|assistant|agent|chatbot) (reads|visits|summari[sz]es|processes) this)/i;
  function promptInjection() {
    const out = [];
    const isHidden = (el) => {
      if (!el || el.nodeType !== 1) return "";
      if (el.closest("[hidden],[aria-hidden='true'],noscript,template")) return "hidden attribute";
      const s = getComputedStyle(el);
      if (s.display === "none") return "display:none";
      if (s.visibility === "hidden") return "visibility:hidden";
      if (Number(s.opacity) < 0.05) return "transparent";
      if (parseFloat(s.fontSize) < 3) return "tiny text";
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return s.overflow === "hidden" ? "clipped to nothing" : "";
      if (r.right < 0 || r.bottom < -2000 || r.left > innerWidth + 2000) return "positioned off-screen";
      if (s.color && s.backgroundColor && s.color === s.backgroundColor) return "text colour equals background";
      if (/rect\(0(px)?,? 0(px)?,? 0(px)?,? 0(px)?\)|inset\(50%\)/.test(s.clip + " " + s.clipPath)) return "clipped to nothing";
      return "";
    };
    try {
      const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
      for (let n = walker.nextNode(), i = 0; n && i < 30000 && out.length < 8; n = walker.nextNode(), i++) {
        const text = n.nodeValue;
        if (!text || text.length < 12) continue;
        const m = AGENT.exec(text);
        if (!m) continue;
        const how = isHidden(n.parentElement);
        out.push({ hidden: !!how, how: how || "visible", sample: text.replace(/\s+/g, " ").trim().slice(0, 140) });
      }
      for (const el of document.querySelectorAll("[alt],[title],[aria-label],meta[content]")) {
        const v = el.getAttribute("alt") || el.getAttribute("title") || el.getAttribute("aria-label") || el.getAttribute("content") || "";
        if (v.length >= 12 && AGENT.test(v)) { out.push({ hidden: true, how: "inside an attribute", sample: v.slice(0, 140) }); if (out.length >= 8) break; }
      }
      const walker2 = document.createTreeWalker(document.documentElement, NodeFilter.SHOW_COMMENT);
      for (let n = walker2.nextNode(), i = 0; n && i < 400; n = walker2.nextNode(), i++) if (AGENT.test(n.nodeValue || "")) { out.push({ hidden: true, how: "html comment", sample: n.nodeValue.trim().slice(0, 140) }); break; }
    } catch {}
    return out;
  }

  api.runtime.onMessage.addListener((message, sender, reply) => {
    if (message && message.type === "audit.facts") {
      (async () => {
        let facts;
        try { facts = collect(); } catch { reply({ error: true }); return; }
        try { if (navigator.serviceWorker && navigator.serviceWorker.getRegistrations) { const regs = await navigator.serviceWorker.getRegistrations(); facts.serviceWorkers = regs.map((r) => ({ scope: String(r.scope).slice(0, 120) })); } } catch {}
        reply(facts);
      })();
      return true;
    }
  });
})();
